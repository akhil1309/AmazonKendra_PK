import React from "react";

import {
  DocumentAttributeKeys,
  AdditionalResultAttributeKeys
} from "../constants";
import { isNullOrUndefined } from "../utils";
import { QueryResultItem, QueryResultItemList } from "./../kendraTypes";

import ResultTitle from "./components/ResultTitle";
import ResultText from "./components/ResultText";
import ResultFooter from "./components/ResultFooter";

import "../search.css";

const KENDRA_SUGGESTED_ANSWERS = "Kendra suggested answers";

interface TopResultsProps {
  results: QueryResultItemList;
}

export default class TopResults extends React.Component<TopResultsProps, {}> {
  // All results in this component has QueryResultType === "ANSWER"
  private renderResults = (result: QueryResultItem, idx: number) => {
    if (!isNullOrUndefined(result)) {
      let attributes = Object();
      if (!isNullOrUndefined(result.DocumentAttributes)) {
        result.DocumentAttributes!.forEach(attribute => {
          attributes[attribute.Key] = attribute.Value;
        });
      }

      let resultAttributes = Object();
      if (!isNullOrUndefined(result.AdditionalAttributes)) {
        result.AdditionalAttributes!.forEach(attribute => {
          resultAttributes[attribute.Key] = attribute.Value;
        });
      }

      const answer = resultAttributes[AdditionalResultAttributeKeys.AnswerText];
      const createdAt = attributes[DocumentAttributeKeys.CreatedAt];

      return (
        <React.Fragment key={result.Id}>
          <div className="container-divider" />
          <div className="container-body">
            <ResultTitle queryResultItem={result} attributes={attributes} />
            <ResultText
              className="small-bottom-margin"
              text={answer.TextWithHighlightsValue}
              createdAt={createdAt}
            />
            <ResultFooter queryResultItem={result} attributes={attributes} />
          </div>
        </React.Fragment>
      );
    } else {
      return null;
    }
  };

  render() {
    const { results } = this.props;

    if (isNullOrUndefined(results) || results.length === 0) {
      return null;
    }

    return (
      <div className="result-container card">
        <div className="card-title">{KENDRA_SUGGESTED_ANSWERS}</div>
        {results.map(this.renderResults)}
      </div>
    );
  }
}
