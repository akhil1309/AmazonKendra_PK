import React from "react";

import { DocumentAttributeValue, TextWithHighlights } from "../../kendraTypes";
import { isNullOrUndefined, localizedDate } from "../../utils";

import TextHighlights from "./TextWithHighlight";
import "./../../search.css";

interface ResultTextProps {
  createdAt?: DocumentAttributeValue;
  text: TextWithHighlights;
  className?: string;
}

export default class ResultText extends React.Component<ResultTextProps, {}> {
  constructor(props: ResultTextProps) {
    super(props);
  }

  /**
   * Render text without truncation
   */
  private renderNotTruncated = (text: TextWithHighlights) => {
    return (
      <span>
        <TextHighlights textWithHighlights={text} />
      </span>
    );
  };

  private renderResult = () => {
    const { text } = this.props;

    if (isNullOrUndefined(text)) {
      return null;
    } else {
      return this.renderNotTruncated(text);
    }
  };

  public formatDateString = (dateStr: string) => {
    const date = localizedDate(new Date(dateStr), {
      day: "2-digit",
      month: "short",
      year: "numeric"
    });

    return `${date} - `;
  };

  render() {
    const { createdAt } = this.props;

    const date = createdAt
      ? this.formatDateString(createdAt.StringValue!)
      : undefined;

    return (
      <div className={this.props.className}>
        {date && <span>{date} </span>}
        <span>{this.renderResult()}</span>
      </div>
    );
  }
}
